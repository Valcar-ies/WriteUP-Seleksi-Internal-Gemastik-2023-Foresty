//NOMOR 1

//fungsi menghitung ganjil dan penambahan ganjil
function calculateOddSum(min, max) {
    let sum = 0;
    for (let i = min; i <= max; i++) {
        if (i % 2 !== 0) {
            sum += i;
        }
    }
    return sum;
}

//fungsi menampilkan hasil dari penghitungan
function calculateAndDisplay() {
    const minInput = document.getElementById('min');
    const maxInput = document.getElementById('max');
    const resultContainer = document.getElementById('result');

    const min = parseInt(minInput.value);
    const max = parseInt(maxInput.value);

    if (!isNaN(min) && !isNaN(max)) {
        const result = calculateOddSum(min, max);
        resultContainer.textContent = `Result: ${result}`;
    } else {
        resultContainer.textContent = 'Invalid input. Please enter valid numbers.';
    }
}

//NOMOR 2

//Fungsi mengubah background color
function toggleDarkMode() {
    const body = document.body;
    body.classList.toggle('dark-mode');
}

//fungsi mengubah text-align
document.getElementById('alignmentToggle').addEventListener('click', function() {
    document.body.classList.toggle('align-right');
});