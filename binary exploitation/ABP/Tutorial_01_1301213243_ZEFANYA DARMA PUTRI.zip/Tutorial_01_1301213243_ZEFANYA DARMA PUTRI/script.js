function redirectToForm() {
    window.location.href = 'form.html';
}

function showThankYouMessage() {
    alert("Thank you for your participation!");
}